//
//  ViewController.swift
//  FirstAppSwiftFunFacts
//
//  Created by Francisco Palacios on 11/28/17.
//  Copyright © 2017 Francisco Palacios. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var funFactLabel: UILabel!
    @IBOutlet weak var funFactButton: UIButton!

    
    let factProvider = FactsProvider();
    let backGroundColor = BackgroundColorProvider();
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        funFactLabel.text = factProvider.randomFact()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func showFact() {
        funFactLabel.text = factProvider.randomFact()
        let randomColor = backGroundColor.randomColor()
        view.backgroundColor = randomColor
        funFactButton.tintColor = randomColor
        
    }

}

